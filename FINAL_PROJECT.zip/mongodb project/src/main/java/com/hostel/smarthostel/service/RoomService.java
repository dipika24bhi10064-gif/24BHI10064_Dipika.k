package com.hostel.smarthostel.service;

import com.hostel.smarthostel.model.Room;
import com.hostel.smarthostel.repository.RoomRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class RoomService {

    private final RoomRepository roomRepository;

    public RoomService(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }

    public Room createRoom(Room room) {
        if (roomRepository.existsById(room.getRoomId())) {
            throw new RuntimeException("Room ID already exists: " + room.getRoomId());
        }
        if (roomRepository.findByRoomNumber(room.getRoomNumber()).isPresent()) {
            throw new RuntimeException("Room number already exists: " + room.getRoomNumber());
        }
        room.setOccupancy(0);
        room.setRoomStatus("AVAILABLE");
        return roomRepository.save(room);
    }

    public Room getRoomById(String id) {
        return roomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Room not found with ID: " + id));
    }

    public Page<Room> getAllRooms(String search, Pageable pageable) {
        if (search != null && !search.trim().isEmpty()) {
            return roomRepository.findByBlockContainingIgnoreCaseOrRoomStatus(search, search, pageable);
        }
        return roomRepository.findAll(pageable);
    }

    public Room updateRoom(String id, Room updated) {
        Room existing = getRoomById(id);

        if (updated.getCapacity() < existing.getOccupancy()) {
            throw new RuntimeException("Cannot lower room capacity below the current occupancy");
        }

        existing.setBlock(updated.getBlock());
        existing.setCapacity(updated.getCapacity());
        
        if ("FULL".equals(updated.getRoomStatus()) && existing.getOccupancy() < updated.getCapacity()) {
            existing.setRoomStatus("AVAILABLE");
        } else {
            existing.setRoomStatus(updated.getRoomStatus());
        }

        if (existing.getOccupancy().equals(existing.getCapacity())) {
            existing.setRoomStatus("FULL");
        }

        return roomRepository.save(existing);
    }

    public void deleteRoom(String id) {
        Room room = getRoomById(id);
        if (room.getOccupancy() > 0) {
            throw new RuntimeException("Cannot delete room because it is currently occupied");
        }
        roomRepository.deleteById(id);
    }
}
