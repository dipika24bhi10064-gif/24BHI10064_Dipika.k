package com.hostel.smarthostel.repository;

import com.hostel.smarthostel.model.Room;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface RoomRepository extends MongoRepository<Room, String> {
    Optional<Room> findByRoomNumber(String roomNumber);
    Page<Room> findByBlockContainingIgnoreCaseOrRoomStatus(String block, String roomStatus, Pageable pageable);
    List<Room> findByRoomStatus(String roomStatus);
    long countByRoomStatus(String roomStatus);
}
