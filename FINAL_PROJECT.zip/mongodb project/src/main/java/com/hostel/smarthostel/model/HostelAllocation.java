package com.hostel.smarthostel.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Document(collection = "hostel_allocations")
public class HostelAllocation {
    @Id
    private String allocationId;
    private String studentId;
    private String roomId;
    private String roomNumber;
    private LocalDate allocationDate;
    private String status; // "ACTIVE", "VACATED"

    public HostelAllocation() {}

    public HostelAllocation(String allocationId, String studentId, String roomId, String roomNumber, LocalDate allocationDate, String status) {
        this.allocationId = allocationId;
        this.studentId = studentId;
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.allocationDate = allocationDate;
        this.status = status;
    }

    public static HostelAllocationBuilder builder() {
        return new HostelAllocationBuilder();
    }

    public String getAllocationId() {
        return allocationId;
    }

    public void setAllocationId(String allocationId) {
        this.allocationId = allocationId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public LocalDate getAllocationDate() {
        return allocationDate;
    }

    public void setAllocationDate(LocalDate allocationDate) {
        this.allocationDate = allocationDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static class HostelAllocationBuilder {
        private String allocationId;
        private String studentId;
        private String roomId;
        private String roomNumber;
        private LocalDate allocationDate;
        private String status;

        public HostelAllocationBuilder allocationId(String allocationId) {
            this.allocationId = allocationId;
            return this;
        }

        public HostelAllocationBuilder studentId(String studentId) {
            this.studentId = studentId;
            return this;
        }

        public HostelAllocationBuilder roomId(String roomId) {
            this.roomId = roomId;
            return this;
        }

        public HostelAllocationBuilder roomNumber(String roomNumber) {
            this.roomNumber = roomNumber;
            return this;
        }

        public HostelAllocationBuilder allocationDate(LocalDate allocationDate) {
            this.allocationDate = allocationDate;
            return this;
        }

        public HostelAllocationBuilder status(String status) {
            this.status = status;
            return this;
        }

        public HostelAllocation build() {
            return new HostelAllocation(allocationId, studentId, roomId, roomNumber, allocationDate, status);
        }
    }
}
