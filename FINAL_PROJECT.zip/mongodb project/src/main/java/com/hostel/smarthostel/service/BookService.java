package com.hostel.smarthostel.service;

import com.hostel.smarthostel.model.Book;
import com.hostel.smarthostel.model.BookBorrowRecord;
import com.hostel.smarthostel.repository.BookRepository;
import com.hostel.smarthostel.repository.BookBorrowRecordRepository;
import com.hostel.smarthostel.repository.StudentRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    private final BookRepository bookRepository;
    private final BookBorrowRecordRepository bookBorrowRecordRepository;
    private final StudentRepository studentRepository;

    public BookService(BookRepository bookRepository,
                       BookBorrowRecordRepository bookBorrowRecordRepository,
                       StudentRepository studentRepository) {
        this.bookRepository = bookRepository;
        this.bookBorrowRecordRepository = bookBorrowRecordRepository;
        this.studentRepository = studentRepository;
    }

    public Book createBook(Book book) {
        if (bookRepository.existsById(book.getBookId())) {
            throw new RuntimeException("Book ID already exists: " + book.getBookId());
        }
        if (bookRepository.existsByIsbn(book.getIsbn())) {
            throw new RuntimeException("Book with ISBN already exists: " + book.getIsbn());
        }
        // Initially, availableCopies = total quantity
        book.setAvailableCopies(book.getQuantity());
        return bookRepository.save(book);
    }

    public Book getBookById(String id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found with ID: " + id));
    }

    public Page<Book> getAllBooks(String search, Pageable pageable) {
        if (search != null && !search.trim().isEmpty()) {
            return bookRepository.findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCaseOrCategoryContainingIgnoreCaseOrIsbnContainingIgnoreCase(
                    search, search, search, search, pageable);
        }
        return bookRepository.findAll(pageable);
    }

    public Book updateBook(String id, Book updated) {
        Book existing = getBookById(id);
        
        // Calculate difference in quantity to adjust available copies
        int diff = updated.getQuantity() - existing.getQuantity();
        int newAvailable = existing.getAvailableCopies() + diff;
        if (newAvailable < 0) {
            throw new RuntimeException("Cannot lower quantity below the number of currently issued copies");
        }

        existing.setTitle(updated.getTitle());
        existing.setAuthor(updated.getAuthor());
        existing.setCategory(updated.getCategory());
        existing.setIsbn(updated.getIsbn());
        existing.setQuantity(updated.getQuantity());
        existing.setAvailableCopies(newAvailable);

        return bookRepository.save(existing);
    }

    public void deleteBook(String id) {
        Book book = getBookById(id);
        // Prevent deletion if copies are currently borrowed
        if (book.getAvailableCopies() < book.getQuantity()) {
            throw new RuntimeException("Cannot delete book because some copies are currently borrowed");
        }
        bookRepository.deleteById(id);
    }

    // --- Borrowing System (Many-to-Many Relationship Mappings) ---

    public BookBorrowRecord borrowBook(String studentId, String bookId) {
        // 1. Verify Student exists
        if (!studentRepository.existsById(studentId)) {
            throw new RuntimeException("Student not found with ID: " + studentId);
        }

        // 2. Verify Book exists
        Book book = getBookById(bookId);

        // 3. Verify availability
        if (book.getAvailableCopies() <= 0) {
            throw new RuntimeException("No copies available for borrowing");
        }

        // 4. Verify student hasn't already borrowed the same book
        Optional<BookBorrowRecord> existingRecord = bookBorrowRecordRepository
                .findByStudentIdAndBookIdAndStatus(studentId, bookId, "BORROWED");
        if (existingRecord.isPresent()) {
            throw new RuntimeException("Student has already borrowed this book and not returned it yet");
        }

        // 5. Deduct copy
        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepository.save(book);

        // 6. Create borrow record
        BookBorrowRecord record = BookBorrowRecord.builder()
                .studentId(studentId)
                .bookId(bookId)
                .borrowDate(LocalDate.now())
                .status("BORROWED")
                .build();

        return bookBorrowRecordRepository.save(record);
    }

    public BookBorrowRecord returnBook(String studentId, String bookId) {
        // 1. Verify borrowing record exists
        BookBorrowRecord record = bookBorrowRecordRepository
                .findByStudentIdAndBookIdAndStatus(studentId, bookId, "BORROWED")
                .orElseThrow(() -> new RuntimeException("No active borrow record found for this student and book"));

        // 2. Update record
        record.setStatus("RETURNED");
        record.setReturnDate(LocalDate.now());
        bookBorrowRecordRepository.save(record);

        // 3. Restore book copy
        Book book = getBookById(bookId);
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        bookRepository.save(book);

        return record;
    }

    public List<BookBorrowRecord> getBorrowedBooksByStudent(String studentId) {
        return bookBorrowRecordRepository.findByStudentId(studentId);
    }
}
