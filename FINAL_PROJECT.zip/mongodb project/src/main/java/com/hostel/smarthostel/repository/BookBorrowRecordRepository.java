package com.hostel.smarthostel.repository;

import com.hostel.smarthostel.model.BookBorrowRecord;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookBorrowRecordRepository extends MongoRepository<BookBorrowRecord, String> {
    List<BookBorrowRecord> findByStudentId(String studentId);
    List<BookBorrowRecord> findByStudentIdAndStatus(String studentId, String status);
    List<BookBorrowRecord> findByBookId(String bookId);
    Optional<BookBorrowRecord> findByStudentIdAndBookIdAndStatus(String studentId, String bookId, String status);
    long countByStatus(String status);
}
