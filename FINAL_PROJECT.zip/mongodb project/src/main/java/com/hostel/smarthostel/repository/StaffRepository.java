package com.hostel.smarthostel.repository;

import com.hostel.smarthostel.model.Staff;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StaffRepository extends MongoRepository<Staff, String> {
    Optional<Staff> findByEmail(String email);
    Page<Staff> findByNameContainingIgnoreCaseOrDesignationContainingIgnoreCase(String name, String designation, Pageable pageable);
    List<Staff> findByDepartmentId(String departmentId);
    long countByDepartmentId(String departmentId);
}
