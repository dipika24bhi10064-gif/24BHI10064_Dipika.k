package com.hostel.smarthostel.repository;

import com.hostel.smarthostel.model.HostelAllocation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface HostelAllocationRepository extends MongoRepository<HostelAllocation, String> {
    Optional<HostelAllocation> findByStudentIdAndStatus(String studentId, String status);
    Optional<HostelAllocation> findByStudentId(String studentId);
    List<HostelAllocation> findByRoomIdAndStatus(String roomId, String status);
}
