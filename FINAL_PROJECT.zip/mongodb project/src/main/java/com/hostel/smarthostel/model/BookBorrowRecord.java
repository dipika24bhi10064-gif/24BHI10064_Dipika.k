package com.hostel.smarthostel.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Document(collection = "book_borrow_records")
public class BookBorrowRecord {
    @Id
    private String borrowId;
    private String studentId;
    private String bookId;
    private LocalDate borrowDate;
    private LocalDate returnDate;
    private String status; // "BORROWED", "RETURNED"

    public BookBorrowRecord() {}

    public BookBorrowRecord(String borrowId, String studentId, String bookId, LocalDate borrowDate, LocalDate returnDate, String status) {
        this.borrowId = borrowId;
        this.studentId = studentId;
        this.bookId = bookId;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
        this.status = status;
    }

    public static BookBorrowRecordBuilder builder() {
        return new BookBorrowRecordBuilder();
    }

    public String getBorrowId() {
        return borrowId;
    }

    public void setBorrowId(String borrowId) {
        this.borrowId = borrowId;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDate returnDate) {
        this.returnDate = returnDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public static class BookBorrowRecordBuilder {
        private String borrowId;
        private String studentId;
        private String bookId;
        private LocalDate borrowDate;
        private LocalDate returnDate;
        private String status;

        public BookBorrowRecordBuilder borrowId(String borrowId) {
            this.borrowId = borrowId;
            return this;
        }

        public BookBorrowRecordBuilder studentId(String studentId) {
            this.studentId = studentId;
            return this;
        }

        public BookBorrowRecordBuilder bookId(String bookId) {
            this.bookId = bookId;
            return this;
        }

        public BookBorrowRecordBuilder borrowDate(LocalDate borrowDate) {
            this.borrowDate = borrowDate;
            return this;
        }

        public BookBorrowRecordBuilder returnDate(LocalDate returnDate) {
            this.returnDate = returnDate;
            return this;
        }

        public BookBorrowRecordBuilder status(String status) {
            this.status = status;
            return this;
        }

        public BookBorrowRecord build() {
            return new BookBorrowRecord(borrowId, studentId, bookId, borrowDate, returnDate, status);
        }
    }
}
