package com.hostel.smarthostel.controller;

import com.hostel.smarthostel.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@Tag(name = "Analytics Dashboard", description = "Endpoints for viewing aggregate stats across all hostel modules. Restrictive to Admin/Staff roles.")
public class DashboardController {

    private final DashboardService dashboardService;
    private final PasswordEncoder passwordEncoder;

    public DashboardController(DashboardService dashboardService, PasswordEncoder passwordEncoder) {
        this.dashboardService = dashboardService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/stats")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    @Operation(summary = "Get aggregate statistics for hostel management dashboard (Admin/Staff only)",
            description = "Computes active room occupancies, book distributions, student counts by department, staff sizes, and occupancy rate.")
    public ResponseEntity<Map<String, Object>> getDashboardStats() {
        return ResponseEntity.ok(dashboardService.getDashboardStats());
    }

    @PostMapping("/reset")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Reset entire database (Admin only)",
            description = "Drops all MongoDB collections and re-seeds the default admin credentials (admin@hostel.com / admin123).")
    public ResponseEntity<String> resetDatabase() {
        dashboardService.resetDatabase(passwordEncoder);
        return ResponseEntity.ok("Database reset and seeded with default admin account successfully!");
    }
}
