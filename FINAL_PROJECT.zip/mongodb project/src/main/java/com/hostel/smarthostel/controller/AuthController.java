package com.hostel.smarthostel.controller;

import com.hostel.smarthostel.dto.AuthResponse;
import com.hostel.smarthostel.dto.LoginRequest;
import com.hostel.smarthostel.dto.RegisterRequest;
import com.hostel.smarthostel.model.User;
import com.hostel.smarthostel.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@Tag(name = "Authentication Module", description = "Endpoints for student, staff, and admin registration and login.")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/register")
    @Operation(summary = "Register a new user (Student, Staff, or Admin)", 
            description = "Creates login credentials. If role is STUDENT or STAFF, it also initializes their corresponding profile document.")
    public ResponseEntity<?> registerUser(@Valid @RequestBody RegisterRequest request) {
        try {
            User registeredUser = authService.register(request);
            return new ResponseEntity<>(registeredUser, HttpStatus.CREATED);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/login")
    @Operation(summary = "Authenticate user and generate JWT token", 
            description = "Verifies email and password. Returns user email, role, and the JWT bearer authorization token.")
    public ResponseEntity<?> loginUser(@Valid @RequestBody LoginRequest request) {
        try {
            AuthResponse response = authService.login(request);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
        }
    }
}
