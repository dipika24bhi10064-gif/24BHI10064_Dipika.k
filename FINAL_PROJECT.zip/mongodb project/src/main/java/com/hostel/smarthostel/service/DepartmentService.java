package com.hostel.smarthostel.service;

import com.hostel.smarthostel.model.Department;
import com.hostel.smarthostel.repository.DepartmentRepository;
import com.hostel.smarthostel.repository.StudentRepository;
import com.hostel.smarthostel.repository.StaffRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class DepartmentService {

    private final DepartmentRepository departmentRepository;
    private final StudentRepository studentRepository;
    private final StaffRepository staffRepository;

    public DepartmentService(DepartmentRepository departmentRepository,
                             StudentRepository studentRepository,
                             StaffRepository staffRepository) {
        this.departmentRepository = departmentRepository;
        this.studentRepository = studentRepository;
        this.staffRepository = staffRepository;
    }

    public Department createDepartment(Department department) {
        if (departmentRepository.existsById(department.getDepartmentId())) {
            throw new RuntimeException("Department ID already exists: " + department.getDepartmentId());
        }
        return departmentRepository.save(department);
    }

    public Department getDepartmentById(String id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Department not found with ID: " + id));
    }

    public Page<Department> getAllDepartments(String search, Pageable pageable) {
        if (search != null && !search.trim().isEmpty()) {
            return departmentRepository.findByDepartmentNameContainingIgnoreCase(search, pageable);
        }
        return departmentRepository.findAll(pageable);
    }

    public Department updateDepartment(String id, Department updatedDepartment) {
        Department existing = getDepartmentById(id);
        existing.setDepartmentName(updatedDepartment.getDepartmentName());
        existing.setDescription(updatedDepartment.getDescription());
        return departmentRepository.save(existing);
    }

    public void deleteDepartment(String id) {
        // Prevent deletion if department is referenced by students or staff
        if (studentRepository.countByDepartmentId(id) > 0) {
            throw new RuntimeException("Cannot delete department because students are enrolled in it");
        }
        if (staffRepository.countByDepartmentId(id) > 0) {
            throw new RuntimeException("Cannot delete department because staff are working in it");
        }
        departmentRepository.deleteById(id);
    }
}
