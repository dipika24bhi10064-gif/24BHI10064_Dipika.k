package com.hostel.smarthostel.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Document(collection = "students")
public class Student {
    @Id
    private String studentId;
    private String name;
    private String email;
    private String phone;
    private String gender;
    private String roomNumber;
    private String departmentId;
    private LocalDate joiningDate;
    private String hostelStatus; // "PENDING", "ALLOCATED", "VACATED"

    public Student() {}

    public Student(String studentId, String name, String email, String phone, String gender, String roomNumber, String departmentId, LocalDate joiningDate, String hostelStatus) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.gender = gender;
        this.roomNumber = roomNumber;
        this.departmentId = departmentId;
        this.joiningDate = joiningDate;
        this.hostelStatus = hostelStatus;
    }

    public static StudentBuilder builder() {
        return new StudentBuilder();
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public LocalDate getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(LocalDate joiningDate) {
        this.joiningDate = joiningDate;
    }

    public String getHostelStatus() {
        return hostelStatus;
    }

    public void setHostelStatus(String hostelStatus) {
        this.hostelStatus = hostelStatus;
    }

    public static class StudentBuilder {
        private String studentId;
        private String name;
        private String email;
        private String phone;
        private String gender;
        private String roomNumber;
        private String departmentId;
        private LocalDate joiningDate;
        private String hostelStatus;

        public StudentBuilder studentId(String studentId) {
            this.studentId = studentId;
            return this;
        }

        public StudentBuilder name(String name) {
            this.name = name;
            return this;
        }

        public StudentBuilder email(String email) {
            this.email = email;
            return this;
        }

        public StudentBuilder phone(String phone) {
            this.phone = phone;
            return this;
        }

        public StudentBuilder gender(String gender) {
            this.gender = gender;
            return this;
        }

        public StudentBuilder roomNumber(String roomNumber) {
            this.roomNumber = roomNumber;
            return this;
        }

        public StudentBuilder departmentId(String departmentId) {
            this.departmentId = departmentId;
            return this;
        }

        public StudentBuilder joiningDate(LocalDate joiningDate) {
            this.joiningDate = joiningDate;
            return this;
        }

        public StudentBuilder hostelStatus(String hostelStatus) {
            this.hostelStatus = hostelStatus;
            return this;
        }

        public Student build() {
            return new Student(studentId, name, email, phone, gender, roomNumber, departmentId, joiningDate, hostelStatus);
        }
    }
}
