package com.hostel.smarthostel.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "staff")
public class Staff {
    @Id
    private String staffId;
    private String name;
    private String email;
    private String designation;
    private Double salary;
    private String departmentId;
    private String contactNumber;

    public Staff() {}

    public Staff(String staffId, String name, String email, String designation, Double salary, String departmentId, String contactNumber) {
        this.staffId = staffId;
        this.name = name;
        this.email = email;
        this.designation = designation;
        this.salary = salary;
        this.departmentId = departmentId;
        this.contactNumber = contactNumber;
    }

    public static StaffBuilder builder() {
        return new StaffBuilder();
    }

    public String getStaffId() {
        return staffId;
    }

    public void setStaffId(String staffId) {
        this.staffId = staffId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public String getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentId(String departmentId) {
        this.departmentId = departmentId;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public static class StaffBuilder {
        private String staffId;
        private String name;
        private String email;
        private String designation;
        private Double salary;
        private String departmentId;
        private String contactNumber;

        public StaffBuilder staffId(String staffId) {
            this.staffId = staffId;
            return this;
        }

        public StaffBuilder name(String name) {
            this.name = name;
            return this;
        }

        public StaffBuilder email(String email) {
            this.email = email;
            return this;
        }

        public StaffBuilder designation(String designation) {
            this.designation = designation;
            return this;
        }

        public StaffBuilder salary(Double salary) {
            this.salary = salary;
            return this;
        }

        public StaffBuilder departmentId(String departmentId) {
            this.departmentId = departmentId;
            return this;
        }

        public StaffBuilder contactNumber(String contactNumber) {
            this.contactNumber = contactNumber;
            return this;
        }

        public Staff build() {
            return new Staff(staffId, name, email, designation, salary, departmentId, contactNumber);
        }
    }
}
