package com.hostel.smarthostel.config;

import com.hostel.smarthostel.model.*;
import com.hostel.smarthostel.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import java.util.Arrays;

@Component
public class DatabaseSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DatabaseSeeder.class);

    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final RoomRepository roomRepository;
    private final BookRepository bookRepository;
    private final PasswordEncoder passwordEncoder;

    public DatabaseSeeder(UserRepository userRepository,
                          DepartmentRepository departmentRepository,
                          RoomRepository roomRepository,
                          BookRepository bookRepository,
                          PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.departmentRepository = departmentRepository;
        this.roomRepository = roomRepository;
        this.bookRepository = bookRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        log.info("Database seeding verification started...");

        // 1. Seed Default Admin User
        if (!userRepository.existsByEmail("admin@hostel.com")) {
            User admin = User.builder()
                    .id("admin@hostel.com")
                    .email("admin@hostel.com")
                    .password(passwordEncoder.encode("admin123"))
                    .role("ADMIN")
                    .build();
            userRepository.save(admin);
            log.info("Seeded default admin account: admin@hostel.com / admin123");
        }

        // 2. Seed Default Departments
        if (departmentRepository.count() == 0) {
            Department dept1 = Department.builder()
                    .departmentId("DEPT-CS")
                    .departmentName("Computer Science")
                    .description("Department of Computer Science and Engineering")
                    .build();
            Department dept2 = Department.builder()
                    .departmentId("DEPT-EE")
                    .departmentName("Electrical Engineering")
                    .description("Department of Electrical and Electronics Engineering")
                    .build();
            departmentRepository.saveAll(Arrays.asList(dept1, dept2));
            log.info("Seeded default departments: DEPT-CS, DEPT-EE");
        }

        // 3. Seed Default Rooms
        if (roomRepository.count() == 0) {
            Room r1 = Room.builder()
                    .roomId("ROOM-101")
                    .roomNumber("101")
                    .block("A")
                    .capacity(2)
                    .occupancy(0)
                    .roomStatus("AVAILABLE")
                    .build();
            Room r2 = Room.builder()
                    .roomId("ROOM-102")
                    .roomNumber("102")
                    .block("A")
                    .capacity(3)
                    .occupancy(0)
                    .roomStatus("AVAILABLE")
                    .build();
            Room r3 = Room.builder()
                    .roomId("ROOM-201")
                    .roomNumber("201")
                    .block("B")
                    .capacity(2)
                    .occupancy(0)
                    .roomStatus("AVAILABLE")
                    .build();
            roomRepository.saveAll(Arrays.asList(r1, r2, r3));
            log.info("Seeded default rooms: 101, 102, 201");
        }

        // 4. Seed Default Books
        if (bookRepository.count() == 0) {
            Book b1 = Book.builder()
                    .bookId("BOOK-001")
                    .title("Introduction to Algorithms")
                    .author("Thomas H. Cormen")
                    .category("Academics")
                    .isbn("9780262033848")
                    .quantity(5)
                    .availableCopies(5)
                    .build();
            Book b2 = Book.builder()
                    .bookId("BOOK-002")
                    .title("Clean Code")
                    .author("Robert C. Martin")
                    .category("Programming")
                    .isbn("9780132350884")
                    .quantity(3)
                    .availableCopies(3)
                    .build();
            bookRepository.saveAll(Arrays.asList(b1, b2));
            log.info("Seeded default books: BOOK-001, BOOK-002");
        }

        log.info("Database seeding verification completed.");
    }
}
