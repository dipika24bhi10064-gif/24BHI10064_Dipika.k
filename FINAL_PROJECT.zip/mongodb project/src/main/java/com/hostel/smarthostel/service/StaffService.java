package com.hostel.smarthostel.service;

import com.hostel.smarthostel.model.Staff;
import com.hostel.smarthostel.model.User;
import com.hostel.smarthostel.repository.StaffRepository;
import com.hostel.smarthostel.repository.UserRepository;
import com.hostel.smarthostel.repository.DepartmentRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class StaffService {

    private final StaffRepository staffRepository;
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;

    public StaffService(StaffRepository staffRepository,
                        UserRepository userRepository,
                        DepartmentRepository departmentRepository,
                        PasswordEncoder passwordEncoder) {
        this.staffRepository = staffRepository;
        this.userRepository = userRepository;
        this.departmentRepository = departmentRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Staff createStaff(Staff staff) {
        if (staffRepository.existsById(staff.getStaffId())) {
            throw new RuntimeException("Staff ID already exists: " + staff.getStaffId());
        }

        // Validate department
        if (staff.getDepartmentId() != null && !departmentRepository.existsById(staff.getDepartmentId())) {
            throw new RuntimeException("Department not found with ID: " + staff.getDepartmentId());
        }

        // Ensure user login credentials document exists
        if (!userRepository.existsByEmail(staff.getEmail())) {
            User user = User.builder()
                    .id(staff.getEmail())
                    .email(staff.getEmail())
                    .password(passwordEncoder.encode("staff123")) // default temporary password
                    .role("STAFF")
                    .build();
            userRepository.save(user);
        }

        return staffRepository.save(staff);
    }

    public Staff getStaffById(String id) {
        return staffRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Staff not found with ID: " + id));
    }

    public Page<Staff> getAllStaff(String search, Pageable pageable) {
        if (search != null && !search.trim().isEmpty()) {
            return staffRepository.findByNameContainingIgnoreCaseOrDesignationContainingIgnoreCase(search, search, pageable);
        }
        return staffRepository.findAll(pageable);
    }

    public Staff updateStaff(String id, Staff updated) {
        Staff existing = getStaffById(id);

        // Validate department if changing
        if (updated.getDepartmentId() != null && !updated.getDepartmentId().equals(existing.getDepartmentId())) {
            if (!departmentRepository.existsById(updated.getDepartmentId())) {
                throw new RuntimeException("Department not found with ID: " + updated.getDepartmentId());
            }
            existing.setDepartmentId(updated.getDepartmentId());
        }

        existing.setName(updated.getName());
        existing.setDesignation(updated.getDesignation());
        existing.setSalary(updated.getSalary());
        existing.setContactNumber(updated.getContactNumber());

        return staffRepository.save(existing);
    }

    public void deleteStaff(String id) {
        Staff staff = getStaffById(id);
        
        // Delete user login
        userRepository.deleteById(staff.getEmail());
        
        // Delete staff profile
        staffRepository.deleteById(id);
    }
}
