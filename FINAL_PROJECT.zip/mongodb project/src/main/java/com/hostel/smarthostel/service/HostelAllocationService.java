package com.hostel.smarthostel.service;

import com.hostel.smarthostel.model.Student;
import com.hostel.smarthostel.model.Room;
import com.hostel.smarthostel.model.HostelAllocation;
import com.hostel.smarthostel.repository.StudentRepository;
import com.hostel.smarthostel.repository.RoomRepository;
import com.hostel.smarthostel.repository.HostelAllocationRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.Optional;

@Service
public class HostelAllocationService {

    private final StudentRepository studentRepository;
    private final RoomRepository roomRepository;
    private final HostelAllocationRepository hostelAllocationRepository;

    public HostelAllocationService(StudentRepository studentRepository,
                                  RoomRepository roomRepository,
                                  HostelAllocationRepository hostelAllocationRepository) {
        this.studentRepository = studentRepository;
        this.roomRepository = roomRepository;
        this.hostelAllocationRepository = hostelAllocationRepository;
    }

    public HostelAllocation allocateRoom(String studentId, String roomId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found with ID: " + studentId));

        if ("ALLOCATED".equals(student.getHostelStatus())) {
            throw new RuntimeException("Student is already allocated to room: " + student.getRoomNumber());
        }

        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new RuntimeException("Room not found with ID: " + roomId));

        if (!"AVAILABLE".equals(room.getRoomStatus())) {
            throw new RuntimeException("Room is not available for allocation. Current status: " + room.getRoomStatus());
        }
        if (room.getOccupancy() >= room.getCapacity()) {
            throw new RuntimeException("Room is already full");
        }

        room.setOccupancy(room.getOccupancy() + 1);
        if (room.getOccupancy().equals(room.getCapacity())) {
            room.setRoomStatus("FULL");
        }
        roomRepository.save(room);

        student.setHostelStatus("ALLOCATED");
        student.setRoomNumber(room.getRoomNumber());
        studentRepository.save(student);

        Optional<HostelAllocation> existingActive = hostelAllocationRepository.findByStudentIdAndStatus(studentId, "ACTIVE");
        existingActive.ifPresent(alloc -> {
            alloc.setStatus("VACATED");
            hostelAllocationRepository.save(alloc);
        });

        HostelAllocation allocation = HostelAllocation.builder()
                .studentId(studentId)
                .roomId(roomId)
                .roomNumber(room.getRoomNumber())
                .allocationDate(LocalDate.now())
                .status("ACTIVE")
                .build();

        return hostelAllocationRepository.save(allocation);
    }

    public HostelAllocation changeRoom(String studentId, String newRoomId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found with ID: " + studentId));

        HostelAllocation currentAllocation = hostelAllocationRepository.findByStudentIdAndStatus(studentId, "ACTIVE")
                .orElseThrow(() -> new RuntimeException("No active room allocation found for student"));

        if (currentAllocation.getRoomId().equals(newRoomId)) {
            throw new RuntimeException("Student is already allocated to this room");
        }

        Room newRoom = roomRepository.findById(newRoomId)
                .orElseThrow(() -> new RuntimeException("New Room not found with ID: " + newRoomId));

        if (!"AVAILABLE".equals(newRoom.getRoomStatus())) {
            throw new RuntimeException("New Room is not available. Status: " + newRoom.getRoomStatus());
        }
        if (newRoom.getOccupancy() >= newRoom.getCapacity()) {
            throw new RuntimeException("New Room is full");
        }

        Room oldRoom = roomRepository.findById(currentAllocation.getRoomId()).orElse(null);
        if (oldRoom != null) {
            int oldOcc = oldRoom.getOccupancy();
            if (oldOcc > 0) {
                oldRoom.setOccupancy(oldOcc - 1);
                oldRoom.setRoomStatus("AVAILABLE");
                roomRepository.save(oldRoom);
            }
        }

        newRoom.setOccupancy(newRoom.getOccupancy() + 1);
        if (newRoom.getOccupancy().equals(newRoom.getCapacity())) {
            newRoom.setRoomStatus("FULL");
        }
        roomRepository.save(newRoom);

        student.setRoomNumber(newRoom.getRoomNumber());
        studentRepository.save(student);

        currentAllocation.setStatus("VACATED");
        hostelAllocationRepository.save(currentAllocation);

        HostelAllocation newAllocation = HostelAllocation.builder()
                .studentId(studentId)
                .roomId(newRoomId)
                .roomNumber(newRoom.getRoomNumber())
                .allocationDate(LocalDate.now())
                .status("ACTIVE")
                .build();

        return hostelAllocationRepository.save(newAllocation);
    }

    public HostelAllocation vacateRoom(String studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found with ID: " + studentId));

        HostelAllocation allocation = hostelAllocationRepository.findByStudentIdAndStatus(studentId, "ACTIVE")
                .orElseThrow(() -> new RuntimeException("No active room allocation found for student"));

        Room room = roomRepository.findById(allocation.getRoomId()).orElse(null);
        if (room != null) {
            int occ = room.getOccupancy();
            if (occ > 0) {
                room.setOccupancy(occ - 1);
                room.setRoomStatus("AVAILABLE");
                roomRepository.save(room);
            }
        }

        student.setHostelStatus("VACATED");
        student.setRoomNumber(null);
        studentRepository.save(student);

        allocation.setStatus("VACATED");
        return hostelAllocationRepository.save(allocation);
    }

    public HostelAllocation getActiveAllocationByStudent(String studentId) {
        return hostelAllocationRepository.findByStudentIdAndStatus(studentId, "ACTIVE")
                .orElseThrow(() -> new RuntimeException("No active allocation found for student with ID: " + studentId));
    }
}
