package com.hostel.smarthostel.controller;

import com.hostel.smarthostel.model.HostelAllocation;
import com.hostel.smarthostel.service.HostelAllocationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/allocations")
@Tag(name = "Hostel Allocation Module", description = "Endpoints for allocating, changing, or vacating rooms for students. Allocations and changes are Admin-only.")
public class HostelAllocationController {

    private final HostelAllocationService hostelAllocationService;

    public HostelAllocationController(HostelAllocationService hostelAllocationService) {
        this.hostelAllocationService = hostelAllocationService;
    }

    @PostMapping("/allocate")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Allocate a room to a student (Admin only)",
            description = "Assigns the student to the specified room, increments occupancy, and marks student status as ALLOCATED.")
    public ResponseEntity<?> allocateRoom(@RequestParam String studentId, @RequestParam String roomId) {
        try {
            HostelAllocation allocation = hostelAllocationService.allocateRoom(studentId, roomId);
            return new ResponseEntity<>(allocation, HttpStatus.CREATED);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/change")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Change student's room assignment (Admin only)",
            description = "Re-allocates a student to a different room, adjusting occupancy counts for both old and new rooms.")
    public ResponseEntity<?> changeRoom(@RequestParam String studentId, @RequestParam String newRoomId) {
        try {
            HostelAllocation allocation = hostelAllocationService.changeRoom(studentId, newRoomId);
            return ResponseEntity.ok(allocation);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/vacate")
    @PreAuthorize("hasRole('ADMIN') or #studentId == authentication.name")
    @Operation(summary = "Vacate a student from their allocated room (Admin or Student themselves)",
            description = "Removes room assignment, decrements room occupancy, and marks student status as VACATED.")
    public ResponseEntity<?> vacateRoom(@RequestParam String studentId) {
        try {
            HostelAllocation allocation = hostelAllocationService.vacateRoom(studentId);
            return ResponseEntity.ok(allocation);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/active")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF') or #studentId == authentication.name")
    @Operation(summary = "View current active room allocation for a student (Admin/Staff or Student themselves)")
    public ResponseEntity<?> viewRoomAllocation(@RequestParam String studentId) {
        try {
            HostelAllocation allocation = hostelAllocationService.getActiveAllocationByStudent(studentId);
            return ResponseEntity.ok(allocation);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }
}
