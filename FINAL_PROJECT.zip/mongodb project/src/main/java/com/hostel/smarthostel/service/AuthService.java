package com.hostel.smarthostel.service;

import com.hostel.smarthostel.dto.AuthResponse;
import com.hostel.smarthostel.dto.LoginRequest;
import com.hostel.smarthostel.dto.RegisterRequest;
import com.hostel.smarthostel.model.User;
import com.hostel.smarthostel.model.Student;
import com.hostel.smarthostel.model.Staff;
import com.hostel.smarthostel.repository.UserRepository;
import com.hostel.smarthostel.repository.StudentRepository;
import com.hostel.smarthostel.repository.StaffRepository;
import com.hostel.smarthostel.repository.DepartmentRepository;
import com.hostel.smarthostel.config.JwtTokenProvider;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.LocalDate;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final StaffRepository staffRepository;
    private final DepartmentRepository departmentRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenProvider jwtTokenProvider;

    public AuthService(UserRepository userRepository,
                       StudentRepository studentRepository,
                       StaffRepository staffRepository,
                       DepartmentRepository departmentRepository,
                       PasswordEncoder passwordEncoder,
                       JwtTokenProvider jwtTokenProvider) {
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
        this.staffRepository = staffRepository;
        this.departmentRepository = departmentRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    public AuthResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid email or password"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid email or password");
        }

        String token = jwtTokenProvider.generateToken(user.getEmail(), user.getRole());
        return new AuthResponse(user.getEmail(), token, user.getRole());
    }

    public User register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }

        // Validate department if role is Student or Staff
        if (("STUDENT".equalsIgnoreCase(request.getRole()) || "STAFF".equalsIgnoreCase(request.getRole()))
                && request.getDepartmentId() != null) {
            if (!departmentRepository.existsById(request.getDepartmentId())) {
                throw new RuntimeException("Department with ID " + request.getDepartmentId() + " does not exist");
            }
        }

        // Create login credentials
        User user = User.builder()
                .id(request.getEmail())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole().toUpperCase())
                .build();
        userRepository.save(user);

        // Create role-specific profiles
        if ("STUDENT".equalsIgnoreCase(request.getRole())) {
            Student student = Student.builder()
                    .studentId(request.getEmail()) // Email acts as the unique identifier
                    .name(request.getName())
                    .email(request.getEmail())
                    .phone(request.getPhone())
                    .gender(request.getGender())
                    .departmentId(request.getDepartmentId())
                    .joiningDate(LocalDate.now())
                    .hostelStatus("PENDING") // Initial status before allocation
                    .build();
            studentRepository.save(student);
        } else if ("STAFF".equalsIgnoreCase(request.getRole())) {
            Staff staff = Staff.builder()
                    .staffId(request.getEmail()) // Email acts as unique ID
                    .name(request.getName())
                    .email(request.getEmail())
                    .designation(request.getDesignation())
                    .salary(request.getSalary() != null ? request.getSalary() : 0.0)
                    .departmentId(request.getDepartmentId())
                    .contactNumber(request.getContactNumber())
                    .build();
            staffRepository.save(staff);
        }

        return user;
    }
}
