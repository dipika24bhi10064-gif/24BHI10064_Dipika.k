package com.hostel.smarthostel.repository;

import com.hostel.smarthostel.model.Student;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends MongoRepository<Student, String> {
    Optional<Student> findByEmail(String email);
    Page<Student> findByNameContainingIgnoreCaseOrEmailContainingIgnoreCase(String name, String email, Pageable pageable);
    List<Student> findByDepartmentId(String departmentId);
    List<Student> findByRoomNumber(String roomNumber);
    List<Student> findByHostelStatus(String hostelStatus);
    long countByHostelStatus(String hostelStatus);
    long countByDepartmentId(String departmentId);
}
