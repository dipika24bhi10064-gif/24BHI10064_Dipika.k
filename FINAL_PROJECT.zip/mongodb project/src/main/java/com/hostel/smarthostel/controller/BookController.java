package com.hostel.smarthostel.controller;

import com.hostel.smarthostel.model.Book;
import com.hostel.smarthostel.model.BookBorrowRecord;
import com.hostel.smarthostel.service.BookService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/books")
@Tag(name = "Book Management (Library)", description = "Endpoints for library book inventory and book borrowing/returning. Students can search books and request borrows/returns.")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    @Operation(summary = "Add a new book to the library (Admin/Staff only)")
    public ResponseEntity<?> createBook(@RequestBody Book book) {
        try {
            Book created = bookService.createBook(book);
            return new ResponseEntity<>(created, HttpStatus.CREATED);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF', 'STUDENT')")
    @Operation(summary = "Get book details by ID (Admin/Staff/Student)")
    public ResponseEntity<?> getBook(@PathVariable String id) {
        try {
            Book book = bookService.getBookById(id);
            return ResponseEntity.ok(book);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF', 'STUDENT')")
    @Operation(summary = "Get all books with pagination, sorting, and search (Admin/Staff/Student)",
            description = "Search parameter searches by title, author, category, or ISBN. Sort parameter accepts fields like 'title', 'author', 'quantity'.")
    public ResponseEntity<Page<Book>> getAllBooks(
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "title") String sortBy,
            @RequestParam(defaultValue = "asc") String direction) {
        
        Sort sort = direction.equalsIgnoreCase("desc") 
                ? Sort.by(sortBy).descending() 
                : Sort.by(sortBy).ascending();
        Pageable pageable = PageRequest.of(page, size, sort);
        return ResponseEntity.ok(bookService.getAllBooks(search, pageable));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    @Operation(summary = "Update book details (Admin/Staff only)")
    public ResponseEntity<?> updateBook(@PathVariable String id, @RequestBody Book book) {
        try {
            Book updated = bookService.updateBook(id, book);
            return ResponseEntity.ok(updated);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF')")
    @Operation(summary = "Delete book from library (Admin/Staff only)",
            description = "Blocks deletion if any copy of the book is currently borrowed.")
    public ResponseEntity<?> deleteBook(@PathVariable String id) {
        try {
            bookService.deleteBook(id);
            return ResponseEntity.ok("Book deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{id}/borrow")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF') or #studentId == authentication.name")
    @Operation(summary = "Borrow a book (Admin/Staff or Student themselves)",
            description = "Deducts 1 available copy and logs a BORROWED record.")
    public ResponseEntity<?> borrowBook(@PathVariable("id") String bookId, @RequestParam String studentId) {
        try {
            BookBorrowRecord record = bookService.borrowBook(studentId, bookId);
            return new ResponseEntity<>(record, HttpStatus.CREATED);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @PostMapping("/{id}/return")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF') or #studentId == authentication.name")
    @Operation(summary = "Return a book (Admin/Staff or Student themselves)",
            description = "Restores 1 available copy and marks borrowing record as RETURNED.")
    public ResponseEntity<?> returnBook(@PathVariable("id") String bookId, @RequestParam String studentId) {
        try {
            BookBorrowRecord record = bookService.returnBook(studentId, bookId);
            return ResponseEntity.ok(record);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping("/borrowed")
    @PreAuthorize("hasAnyRole('ADMIN', 'STAFF') or #studentId == authentication.name")
    @Operation(summary = "Get student's borrowing history (Admin/Staff or Student themselves)")
    public ResponseEntity<List<BookBorrowRecord>> getBorrowedBooks(@RequestParam String studentId) {
        return ResponseEntity.ok(bookService.getBorrowedBooksByStudent(studentId));
    }
}
