package com.hostel.smarthostel.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "books")
public class Book {
    @Id
    private String bookId;
    private String title;
    private String author;
    private String category;
    private String isbn;
    private Integer quantity;
    private Integer availableCopies;

    public Book() {}

    public Book(String bookId, String title, String author, String category, String isbn, Integer quantity, Integer availableCopies) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.category = category;
        this.isbn = isbn;
        this.quantity = quantity;
        this.availableCopies = availableCopies;
    }

    public static BookBuilder builder() {
        return new BookBuilder();
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getAvailableCopies() {
        return availableCopies;
    }

    public void setAvailableCopies(Integer availableCopies) {
        this.availableCopies = availableCopies;
    }

    public static class BookBuilder {
        private String bookId;
        private String title;
        private String author;
        private String category;
        private String isbn;
        private Integer quantity;
        private Integer availableCopies;

        public BookBuilder bookId(String bookId) {
            this.bookId = bookId;
            return this;
        }

        public BookBuilder title(String title) {
            this.title = title;
            return this;
        }

        public BookBuilder author(String author) {
            this.author = author;
            return this;
        }

        public BookBuilder category(String category) {
            this.category = category;
            return this;
        }

        public BookBuilder isbn(String isbn) {
            this.isbn = isbn;
            return this;
        }

        public BookBuilder quantity(Integer quantity) {
            this.quantity = quantity;
            return this;
        }

        public BookBuilder availableCopies(Integer availableCopies) {
            this.availableCopies = availableCopies;
            return this;
        }

        public Book build() {
            return new Book(bookId, title, author, category, isbn, quantity, availableCopies);
        }
    }
}
