package com.hostel.smarthostel.service;

import com.hostel.smarthostel.model.Student;
import com.hostel.smarthostel.model.User;
import com.hostel.smarthostel.model.Room;
import com.hostel.smarthostel.model.HostelAllocation;
import com.hostel.smarthostel.model.BookBorrowRecord;
import com.hostel.smarthostel.repository.StudentRepository;
import com.hostel.smarthostel.repository.UserRepository;
import com.hostel.smarthostel.repository.DepartmentRepository;
import com.hostel.smarthostel.repository.HostelAllocationRepository;
import com.hostel.smarthostel.repository.BookBorrowRecordRepository;
import com.hostel.smarthostel.repository.RoomRepository;
import com.hostel.smarthostel.repository.BookRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

    private final StudentRepository studentRepository;
    private final UserRepository userRepository;
    private final DepartmentRepository departmentRepository;
    private final HostelAllocationRepository hostelAllocationRepository;
    private final RoomRepository roomRepository;
    private final BookBorrowRecordRepository bookBorrowRecordRepository;
    private final BookRepository bookRepository;
    private final PasswordEncoder passwordEncoder;

    public StudentService(StudentRepository studentRepository,
                          UserRepository userRepository,
                          DepartmentRepository departmentRepository,
                          HostelAllocationRepository hostelAllocationRepository,
                          RoomRepository roomRepository,
                          BookBorrowRecordRepository bookBorrowRecordRepository,
                          BookRepository bookRepository,
                          PasswordEncoder passwordEncoder) {
        this.studentRepository = studentRepository;
        this.userRepository = userRepository;
        this.departmentRepository = departmentRepository;
        this.hostelAllocationRepository = hostelAllocationRepository;
        this.roomRepository = roomRepository;
        this.bookBorrowRecordRepository = bookBorrowRecordRepository;
        this.bookRepository = bookRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Student createStudent(Student student) {
        if (studentRepository.existsById(student.getStudentId())) {
            throw new RuntimeException("Student ID already exists: " + student.getStudentId());
        }

        // Validate department
        if (student.getDepartmentId() != null && !departmentRepository.existsById(student.getDepartmentId())) {
            throw new RuntimeException("Department not found with ID: " + student.getDepartmentId());
        }

        // Setup default status
        student.setHostelStatus("PENDING");
        student.setRoomNumber(null);

        // Ensure a User login credentials document exists
        if (!userRepository.existsByEmail(student.getEmail())) {
            User user = User.builder()
                    .id(student.getEmail())
                    .email(student.getEmail())
                    .password(passwordEncoder.encode("student123")) // default temporary password
                    .role("STUDENT")
                    .build();
            userRepository.save(user);
        }

        return studentRepository.save(student);
    }

    public Student getStudentById(String id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found with ID: " + id));
    }

    public Page<Student> getAllStudents(String search, Pageable pageable) {
        if (search != null && !search.trim().isEmpty()) {
            return studentRepository.findByNameContainingIgnoreCaseOrEmailContainingIgnoreCase(search, search, pageable);
        }
        return studentRepository.findAll(pageable);
    }

    public Student updateStudent(String id, Student updated) {
        Student existing = getStudentById(id);
        
        // Validate department if changing
        if (updated.getDepartmentId() != null && !updated.getDepartmentId().equals(existing.getDepartmentId())) {
            if (!departmentRepository.existsById(updated.getDepartmentId())) {
                throw new RuntimeException("Department not found with ID: " + updated.getDepartmentId());
            }
            existing.setDepartmentId(updated.getDepartmentId());
        }

        existing.setName(updated.getName());
        existing.setPhone(updated.getPhone());
        existing.setGender(updated.getGender());
        
        return studentRepository.save(existing);
    }

    public void deleteStudent(String id) {
        Student student = getStudentById(id);

        // 1. Vacate room if allocated
        Optional<HostelAllocation> allocationOpt = hostelAllocationRepository.findByStudentIdAndStatus(id, "ACTIVE");
        if (allocationOpt.isPresent()) {
            HostelAllocation allocation = allocationOpt.get();
            allocation.setStatus("VACATED");
            hostelAllocationRepository.save(allocation);

            // Update room occupancy
            Room room = roomRepository.findByRoomNumber(allocation.getRoomNumber()).orElse(null);
            if (room != null) {
                int occ = room.getOccupancy();
                if (occ > 0) {
                    room.setOccupancy(occ - 1);
                    room.setRoomStatus("AVAILABLE");
                    roomRepository.save(room);
                }
            }
        }

        // 2. Return any borrowed books
        List<BookBorrowRecord> activeBorrows = bookBorrowRecordRepository.findByStudentIdAndStatus(id, "BORROWED");
        for (BookBorrowRecord record : activeBorrows) {
            record.setStatus("RETURNED");
            bookBorrowRecordRepository.save(record);
            
            bookRepository.findById(record.getBookId()).ifPresent(book -> {
                book.setAvailableCopies(book.getAvailableCopies() + 1);
                bookRepository.save(book);
            });
        }

        // 3. Delete user login
        userRepository.deleteById(student.getEmail());

        // 4. Delete Student profile
        studentRepository.deleteById(id);
    }
}
