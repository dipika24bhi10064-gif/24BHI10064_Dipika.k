package com.hostel.smarthostel.service;

import com.hostel.smarthostel.model.*;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DashboardService {

    private final MongoTemplate mongoTemplate;

    public DashboardService(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public Map<String, Object> getDashboardStats() {
        Map<String, Object> stats = new HashMap<>();

        // 1. Total Students
        long totalStudents = mongoTemplate.count(new Query(), Student.class);
        stats.put("totalStudents", totalStudents);

        // 2. Total Staff
        long totalStaff = mongoTemplate.count(new Query(), Staff.class);
        stats.put("totalStaff", totalStaff);

        // 3. Total Rooms
        long totalRooms = mongoTemplate.count(new Query(), Room.class);
        stats.put("totalRooms", totalRooms);

        // 4. Occupied Rooms (rooms where occupancy > 0)
        long occupiedRooms = mongoTemplate.count(
                Query.query(Criteria.where("occupancy").gt(0)), Room.class);
        stats.put("occupiedRooms", occupiedRooms);

        // 5. Vacant Rooms (rooms where occupancy == 0)
        long vacantRooms = mongoTemplate.count(
                Query.query(Criteria.where("occupancy").is(0)), Room.class);
        stats.put("vacantRooms", vacantRooms);

        // 6. Department-wise Student Count (Aggregation)
        Aggregation studentAgg = Aggregation.newAggregation(
                Aggregation.group("departmentId").count().as("count"),
                Aggregation.project("count").and("departmentId").previousOperation()
        );
        AggregationResults<Map> studentResults = mongoTemplate.aggregate(
                studentAgg, Student.class, Map.class);
        stats.put("departmentWiseStudentCount", studentResults.getMappedResults());

        // 7. Department-wise Staff Count (Aggregation)
        Aggregation staffAgg = Aggregation.newAggregation(
                Aggregation.group("departmentId").count().as("count"),
                Aggregation.project("count").and("departmentId").previousOperation()
        );
        AggregationResults<Map> staffResults = mongoTemplate.aggregate(
                staffAgg, Staff.class, Map.class);
        stats.put("departmentWiseStaffCount", staffResults.getMappedResults());

        // 8. Books Available (sum of availableCopies of all books)
        Aggregation booksAvailableAgg = Aggregation.newAggregation(
                Aggregation.group().sum("availableCopies").as("totalAvailable")
        );
        AggregationResults<Map> booksAvailableResults = mongoTemplate.aggregate(
                booksAvailableAgg, Book.class, Map.class);
        List<Map> booksAvailList = booksAvailableResults.getMappedResults();
        Object totalAvailable = !booksAvailList.isEmpty() ? booksAvailList.get(0).get("totalAvailable") : 0;
        stats.put("booksAvailable", totalAvailable);

        // 9. Books Issued (count of active borrow records with status = "BORROWED")
        long booksIssued = mongoTemplate.count(
                Query.query(Criteria.where("status").is("BORROWED")), BookBorrowRecord.class);
        stats.put("booksIssued", booksIssued);

        // 10. Hostel Occupancy Percentage (Total Occupancy / Total Capacity * 100)
        Aggregation roomOccupancyAgg = Aggregation.newAggregation(
                Aggregation.group()
                        .sum("occupancy").as("totalOccupancy")
                        .sum("capacity").as("totalCapacity")
        );
        AggregationResults<Map> roomOccupancyResults = mongoTemplate.aggregate(
                roomOccupancyAgg, Room.class, Map.class);
        List<Map> roomOccList = roomOccupancyResults.getMappedResults();
        double occupancyPercentage = 0.0;
        if (!roomOccList.isEmpty()) {
            Number totalOcc = (Number) roomOccList.get(0).get("totalOccupancy");
            Number totalCap = (Number) roomOccList.get(0).get("totalCapacity");
            if (totalCap != null && totalCap.doubleValue() > 0) {
                occupancyPercentage = (totalOcc.doubleValue() / totalCap.doubleValue()) * 100.0;
            }
        }
        // Round to 2 decimal places
        stats.put("hostelOccupancyPercentage", Math.round(occupancyPercentage * 100.0) / 100.0);

        return stats;
    }

    public void resetDatabase(org.springframework.security.crypto.password.PasswordEncoder passwordEncoder) {
        mongoTemplate.dropCollection(User.class);
        mongoTemplate.dropCollection(Department.class);
        mongoTemplate.dropCollection(Student.class);
        mongoTemplate.dropCollection(Staff.class);
        mongoTemplate.dropCollection(Room.class);
        mongoTemplate.dropCollection(Book.class);
        mongoTemplate.dropCollection(BookBorrowRecord.class);
        mongoTemplate.dropCollection(HostelAllocation.class);

        // Re-seed default admin
        User admin = User.builder()
                .id("admin@hostel.com")
                .email("admin@hostel.com")
                .password(passwordEncoder.encode("admin123"))
                .role("ADMIN")
                .build();
        mongoTemplate.save(admin);
    }
}
