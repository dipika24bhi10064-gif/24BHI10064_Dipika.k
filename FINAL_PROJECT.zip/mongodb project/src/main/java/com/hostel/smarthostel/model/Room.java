package com.hostel.smarthostel.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "rooms")
public class Room {
    @Id
    private String roomId;
    private String roomNumber;
    private String block;
    private Integer capacity;
    private Integer occupancy;
    private String roomStatus; // "AVAILABLE", "FULL", "MAINTENANCE"

    public Room() {}

    public Room(String roomId, String roomNumber, String block, Integer capacity, Integer occupancy, String roomStatus) {
        this.roomId = roomId;
        this.roomNumber = roomNumber;
        this.block = block;
        this.capacity = capacity;
        this.occupancy = occupancy;
        this.roomStatus = roomStatus;
    }

    public static RoomBuilder builder() {
        return new RoomBuilder();
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Integer getOccupancy() {
        return occupancy;
    }

    public void setOccupancy(Integer occupancy) {
        this.occupancy = occupancy;
    }

    public String getRoomStatus() {
        return roomStatus;
    }

    public void setRoomStatus(String roomStatus) {
        this.roomStatus = roomStatus;
    }

    public static class RoomBuilder {
        private String roomId;
        private String roomNumber;
        private String block;
        private Integer capacity;
        private Integer occupancy;
        private String roomStatus;

        public RoomBuilder roomId(String roomId) {
            this.roomId = roomId;
            return this;
        }

        public RoomBuilder roomNumber(String roomNumber) {
            this.roomNumber = roomNumber;
            return this;
        }

        public RoomBuilder block(String block) {
            this.block = block;
            return this;
        }

        public RoomBuilder capacity(Integer capacity) {
            this.capacity = capacity;
            return this;
        }

        public RoomBuilder occupancy(Integer occupancy) {
            this.occupancy = occupancy;
            return this;
        }

        public RoomBuilder roomStatus(String roomStatus) {
            this.roomStatus = roomStatus;
            return this;
        }

        public Room build() {
            return new Room(roomId, roomNumber, block, capacity, occupancy, roomStatus);
        }
    }
}
