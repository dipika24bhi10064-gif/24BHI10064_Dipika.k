package com.hostel.smarthostel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartHostelApplicationTests {

	@Test
	void contextLoads() {
	}

}
