# Smart Hostel Management System - Project Report

## 1. Executive Summary
The **Smart Hostel Management System** is a backend REST API built using Spring Boot, Java 21, and MongoDB. It provides a secure, robust, and scalable platform for managing college/hostel departments, student registrations, staff data, library books, hostel room allocations, and aggregate dashboard statistics. The application is secured via JWT authentication with Role-Based Access Control (RBAC) supporting **ADMIN**, **STAFF**, and **STUDENT** roles.

---

## 2. Technology Stack & Environment
- **Core Framework**: Spring Boot 3.3.4 (Java 21)
- **Database**: MongoDB Server v6.0+ (running on port `27017`)
- **Security**: Spring Security 6 & JSON Web Token (JJWT 0.12.5)
- **Validation**: Jakarta Bean Validation (`spring-boot-starter-validation`)
- **Documentation**: Springdoc OpenAPI 3.0 / Swagger UI 2.5
- **Boilerplate Reduction**: Project Lombok
- **Java IDE / Build Tool**: Maven (with wrapper `./mvnw`)

---

## 3. Layered Architecture Design
The backend is structured into five distinct, decoupled layers to improve scalability and maintainability:

1. **Model Layer (`com.hostel.smarthostel.model`)**: Models the MongoDB collections as Java documents. Uses annotations like `@Document` and `@Id` to define documents and primary key mappings.
2. **Repository Layer (`com.hostel.smarthostel.repository`)**: Implements data access using Spring Data MongoDB. Extends `MongoRepository` to expose out-of-the-box CRUD, search, pagination, and sorting queries.
3. **Service Layer (`com.hostel.smarthostel.service`)**: Governs business logic, constraints, and multi-document consistency (e.g., allocating a room requires updating Room occupancy, Student status, and writing HostelAllocation logs). Uses `MongoTemplate` for multi-stage analytics aggregation.
4. **Controller Layer (`com.hostel.smarthostel.controller`)**: Exposes REST endpoints (`@RestController`), handles input validation (`@Valid`), manages mapping parameters, and uses Spring Security annotations (`@PreAuthorize`) for RBAC.
5. **Configuration Layer (`com.hostel.smarthostel.config`)**: Standardizes JWT token providers, security filters, database seeders, and Swagger configuration.

---

## 4. Database Relationship Mappings in MongoDB

To represent standard relational mappings in MongoDB without sacrificing document performance, we implemented a combination of references and transaction records:

### A. One-to-One Relationship (Student ↔ Hostel Allocation)
- **Implementation**: Managed using the `HostelAllocation` document referencing `studentId`. When a student is assigned a room, a unique active allocation record is stored with `studentId` and `roomId`.
- **Constraint Handling**: The `HostelAllocationService` checks that a student does not already have an `ACTIVE` allocation in the database before generating a new allocation.

### B. One-to-Many & Many-to-One Relationships (Department ↔ Students/Staff)
- **Implementation**: The `Student` and `Staff` documents store `departmentId` as a reference.
- **Cascading & Integrity Rules**: During student/staff creation, the service validates that the department exists. Deleting a department is blocked if any students or staff are still assigned to it.

### C. Many-to-Many Relationship (Student ↔ Books in Library)
- **Implementation**: Modeled via a helper collection `BookBorrowRecord`. A student can borrow multiple books, and a book can have multiple borrowing histories.
- **Fields**:
  - `borrowId` (Primary Key)
  - `studentId` (Foreign Reference)
  - `bookId` (Foreign Reference)
  - `borrowDate` (LocalDate)
  - `returnDate` (LocalDate, populated on return)
  - `status` ("BORROWED" or "RETURNED")
- **Advantages**: This prevents unbounded array growth in the Student or Book document, which is a known MongoDB anti-pattern.

---

## 5. Security & JWT Token Generation Flow

Spring Security intercepts all incoming requests to authenticate users based on JSON Web Tokens.

```
Client (Login request)
  | 
  v
AuthController (Validates credentials with BCrypt)
  |
  +---> Success ---> JwtTokenProvider (Generates token with Claims: "role" and Subject: "email")
  |
  v
Token returned to Client
```

For subsequent requests:
```
Client (Secured Request + Authorization Bearer header)
  |
  v
JwtAuthenticationFilter (Intercepts request, decodes JWT, parses username & role claim)
  |
  v
SimpleGrantedAuthority created ("ROLE_" + role)
  |
  v
UsernamePasswordAuthenticationToken loaded into SecurityContextHolder
  |
  v
Controller Layer executes (@PreAuthorize evaluates permissions)
```

---

## 6. Advanced Aggregation Queries for Analytics Dashboard

The `/api/dashboard/stats` endpoint calculates real-time hostel metrics using Spring Data `MongoTemplate` aggregations:

1. **Hostel Occupancy Percentage**:
   Calculates total occupancy and total capacity across all rooms, then computes the percentage:
   ```java
   Aggregation roomOccupancyAgg = Aggregation.newAggregation(
       Aggregation.group()
           .sum("occupancy").as("totalOccupancy")
           .sum("capacity").as("totalCapacity")
   );
   ```
2. **Department-Wise Student Count**:
   Groups students by `departmentId` and calculates the total count for each department:
   ```java
   Aggregation studentAgg = Aggregation.newAggregation(
       Aggregation.group("departmentId").count().as("count"),
       Aggregation.project("count").and("departmentId").previousOperation()
   );
   ```
3. **Books Available vs Books Issued**:
   - *Available*: Sums `availableCopies` field across all book documents.
   - *Issued*: Counts active `BookBorrowRecord` documents where status is `"BORROWED"`.

---

## 7. How to Verify & Test the System

### 🔍 A. MongoDB Compass Verification
After running the Spring Boot application and invoking API requests, open **MongoDB Compass** and connect to your local server: `mongodb://localhost:27017`.
- You will see a new database named **`smart_hostel_db`**.
- The database contains the following collections:
  - `users`: Contains login details with BCrypt-encrypted passwords.
  - `departments`: Pre-populated with default departments (`DEPT-CS`, `DEPT-EE`).
  - `students`: Stores student registration details and current room/status mapping.
  - `staff`: Stores staff profiles.
  - `rooms`: Physical room inventory.
  - `hostel_allocations`: Historic and active room allocation logs.
  - `books`: Library books catalog.
  - `book_borrow_records`: Many-to-many transaction logs.

### 💻 B. API Testing with Swagger
1. Open a web browser and navigate to `http://localhost:8080/swagger-ui.html`.
2. Find the **Authentication Module** and call `POST /api/auth/login` with:
   - **Email**: `admin@hostel.com`
   - **Password**: `admin123`
3. Copy the token from the response text.
4. Scroll to the top of the page, click **Authorize**, enter `Bearer <your_copied_token>` (or just the token if using direct Bearer schemes), and validate.
5. Try out adding departments, registering students, allocating rooms, and borrowing books.

---

## 8. Conclusion
The backend meets all structural, database, security, and verification requirements. By utilizing a clean layered design, type-safe services, JWT filters, and multi-stage MongoDB aggregations, this project demonstrates a production-grade backend for hostel resource planning.
