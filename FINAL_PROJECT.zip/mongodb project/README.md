# Smart Hostel Management System (Backend)

A complete, production-ready, REST API-based backend for the **Smart Hostel Management System** built with **Spring Boot**, **Java 21**, and **MongoDB**. The project implements a clean layered architecture, secure role-based access control (RBAC) powered by JWT Authentication, complex database relationship mapping, and advanced dashboard analytics.

---

## 🏛️ Architecture Overview

The system follows a strict **Layered Architecture** pattern to isolate concerns and ease maintainability:

```mermaid
graph TD
    Client[Client / Postman / Swagger UI] -->|REST Request with JWT Header| Controller[Controller Layer]
    Controller -->|DTO Validation| Service[Service Layer]
    Service -->|Business Logics & Transaction Updates| Repository[Repository Layer]
    Repository -->|Spring Data MongoDB queries| Database[(MongoDB Database)]
    
    subgraph ConfigLayer[Configuration Layer]
        SecurityConfig[Security Configuration]
        JwtFilter[JWT Authentication Filter]
        SwaggerConfig[OpenAPI Swagger Specification]
        DatabaseSeeder[Database Seeder on Startup]
    end
    
    ConfigLayer -.->|Secures & Configures| Controller
```

- **Controller Layer**: Handles HTTP requests, enforces request validation (`@Valid`), manages query mapping, and coordinates security bindings.
- **Service Layer**: Orchestrates business logic, maintains transactional safety across multiple document updates, and runs analytics aggregations.
- **Repository Layer**: Extends `MongoRepository` for document actions and relies on `MongoTemplate` for multi-stage aggregation queries.
- **Model/Entity Layer**: Structures data schemas for MongoDB mapping, leveraging Lombok for clean boilerplate-free code.
- **Configuration Layer**: Boots up security parameters, configures Swagger UI OpenAPI spec, and handles database seeding on application boot.

---

## 🗃️ Database Relationship Mapping (ER Diagram)

The backend implements and maintains integrity for the following MongoDB document relationships:

1. **One-to-One**: `Student` ↔ `HostelAllocation` (Each student is mapped to at most one active hostel assignment).
2. **One-to-Many**: `Department` → `Students` (A department can enroll multiple students).
3. **One-to-Many**: `Department` → `Staff` (A department can employ multiple staff members).
4. **Many-to-One**: `Students` → `Department` & `Staff` → `Department` (References stored inside child documents).
5. **Many-to-Many**: `Students` ↔ `Books` (Borrowing System resolved via a transaction-focused `BookBorrowRecord` collection to audit loans without unbounded array growth).

```mermaid
erDiagram
    DEPARTMENT {
        string departmentId PK
        string departmentName
        string description
    }
    STUDENT {
        string studentId PK "maps to email"
        string name
        string email
        string phone
        string gender
        string roomNumber FK
        string departmentId FK
        date joiningDate
        string hostelStatus "PENDING / ALLOCATED / VACATED"
    }
    STAFF {
        string staffId PK "maps to email"
        string name
        string email
        string designation
        double salary
        string departmentId FK
        string contactNumber
    }
    ROOM {
        string roomId PK
        string roomNumber
        string block
        int capacity
        int occupancy
        string roomStatus "AVAILABLE / FULL / MAINTENANCE"
    }
    HOSTEL_ALLOCATION {
        string allocationId PK
        string studentId FK
        string roomId FK
        string roomNumber
        date allocationDate
        string status "ACTIVE / VACATED"
    }
    BOOK {
        string bookId PK
        string title
        string author
        string category
        string isbn
        int quantity
        int availableCopies
    }
    BOOK_BORROW_RECORD {
        string borrowId PK
        string studentId FK
        string bookId FK
        date borrowDate
        date returnDate
        string status "BORROWED / RETURNED"
    }

    DEPARTMENT ||--o{ STUDENT : "enrolls"
    DEPARTMENT ||--o{ STAFF : "employs"
    STUDENT ||--o| HOSTEL_ALLOCATION : "has assignment"
    ROOM ||--o{ HOSTEL_ALLOCATION : "assigned to"
    STUDENT ||--o{ BOOK_BORROW_RECORD : "borrows"
    BOOK ||--o{ BOOK_BORROW_RECORD : "loaned by"
```

---

## 🚀 Getting Started

### 📋 Prerequisites
- **Java Development Kit (JDK)**: Version 21 or above.
- **MongoDB Server**: Running locally on `mongodb://localhost:27017` or configured via a connection URI.
- **Maven**: (A Maven wrapper `./mvnw` is included in the project directory, so you do not need global Maven installed).

### 🛠️ Build and Execution
1. Ensure your local **MongoDB** database is running.
2. Run the application from the root directory using the Maven wrapper:
   ```bash
   ./mvnw spring-boot:run
   ```
3. The server will start on port `8080`.

---

## 🔒 Authentication & Role-Based Access Control (RBAC)

All endpoints (excluding public directories) require a JWT Bearer Token passed in the `Authorization` header as:
`Authorization: Bearer <JWT_TOKEN>`

### 🔑 Seeding Default Accounts
On startup, the system automatically checks and seeds default documents. You can use these credentials to log in immediately:
- **Default Administrator**:
  - **Email**: `admin@hostel.com`
  - **Password**: `admin123`
  - **Role**: `ADMIN`

### 🛡️ Permissions Matrix
| Endpoint Path | Allowed Roles | Description |
| :--- | :--- | :--- |
| `/api/auth/**` | `Public` | Registration and Logins (generate tokens) |
| `/swagger-ui/**` | `Public` | Swagger documentation and testing environment |
| `/api/departments` [GET] | `ADMIN`, `STAFF` | List departments with pagination and search |
| `/api/departments/**` [POST, PUT, DELETE] | `ADMIN` | Manage department details |
| `/api/students` [GET] | `ADMIN`, `STAFF` | List students with pagination and search |
| `/api/students/{id}` [GET, PUT] | `ADMIN`, `STAFF`, `STUDENT (own profile)` | Retrieve or update specific profile details |
| `/api/students/**` [POST, DELETE] | `ADMIN`, `STAFF` | Add or delete student profiles |
| `/api/staff` [GET, POST, DELETE] | `ADMIN` | Manage employee details |
| `/api/staff/{id}` [GET, PUT] | `ADMIN`, `STAFF (own profile)` | Retrieve or update employee profile |
| `/api/rooms` [GET] | `ADMIN`, `STAFF`, `STUDENT` | List available rooms |
| `/api/rooms/**` [POST, PUT, DELETE] | `ADMIN` | Manage room details and capacity |
| `/api/allocations/allocate` [POST] | `ADMIN` | Allocate room to student |
| `/api/allocations/change` [POST] | `ADMIN` | Transfer student to another room |
| `/api/allocations/vacate` [POST] | `ADMIN`, `STUDENT (own)` | Remove room assignment |
| `/api/books` [GET] | `ADMIN`, `STAFF`, `STUDENT` | Browse library inventory |
| `/api/books/**` [POST, PUT, DELETE] | `ADMIN`, `STAFF` | Manage library catalog |
| `/api/books/{id}/borrow` [POST] | `ADMIN`, `STAFF`, `STUDENT (own)` | Borrow a book copy |
| `/api/books/{id}/return` [POST] | `ADMIN`, `STAFF`, `STUDENT (own)` | Return a borrowed book copy |
| `/api/dashboard/stats` [GET] | `ADMIN`, `STAFF` | View aggregate statistics & metrics |
| `/api/dashboard/reset` [POST] | `ADMIN` | Reset all collections (Drop Collection action) |

---

## 📖 API Documentation & Testing

### 🟢 Swagger UI
Once the service starts, access Swagger UI in your browser to inspect and interact with the endpoints:
👉 **[http://localhost:8080/swagger-ui.html](http://localhost:8080/swagger-ui.html)**

**How to test on Swagger**:
1. Call the `POST /api/auth/login` endpoint using the default admin credentials.
2. Copy the token string from the JSON response.
3. Click the **Authorize** button at the top-right of Swagger UI.
4. Paste the token into the field and click **Authorize**.
5. You can now execute secured CRUD, Allocation, Library, and Dashboard requests directly.

### 📬 Postman Collection
An API Collection file is included at the root of the project:
`Smart_Hostel_Management_System.postman_collection.json`
Import this file into Postman, register accounts, login, test roles, search, sort, and paginate through entries.
